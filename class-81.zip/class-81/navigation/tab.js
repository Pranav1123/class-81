import React from 'react';
import Feed from '../Screens/Feed';
import CreateStory from '../Screens/CreateStrory';

import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

const Tab = createBottomTabNavigator();

const BottomTab = () => {
  return (
    <Tab.Navigator>
      <Tab.Screen name="feed" component={Feed} />
      <Tab.Screen name="createstory" component={CreateStory} />
    </Tab.Navigator>
  );
};

export default BottomTab;
