import React from 'react';
import Profile from '../Screens/profile';
import BottomTab from './tab'
import {createDrawerNavigator} from '@react-navigation/drawer';

const Drawer = createDrawerNavigator();

const Drawernavigator = ()=>{
  return(
    <Drawer.Navigator screenOptions={{headerShown:true}}>
    <Drawer.Screen name="Spectagram" component= {BottomTab}/>
    <Drawer.Screen name="profile" component= {Profile}/>
    </Drawer.Navigator>
  )
}
export default Drawernavigator;
