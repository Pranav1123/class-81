import React from 'react';
import {Text,View} from 'react-native'; 
import Drawernavigator from './navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';

export default class App extends React.Component{
  render(){
    return(
      <NavigationContainer>
      <Drawernavigator/>
      </NavigationContainer>
    )
  }
}