import React from 'react';
import {Text,View} from 'react-native';

export default class Profile extends React.Component{
  render(){
    return(
      <View>
      <Text>Profile Screen</Text>
      </View>
    )
  }
}

